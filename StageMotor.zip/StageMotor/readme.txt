run launch vi to open stage motor application
click on "connect" to open session with motor interface
click on "switch direction" to choose direction in which motor to rotate
click on "move to next step" to move to next arbitrary position (within +- 5 steps).
when the user hits "Stop", application will send message to interrupt and stop.



